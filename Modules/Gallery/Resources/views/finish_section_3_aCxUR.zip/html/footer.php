<!-- footer content -->
<footer>
    <div class="pull-right">
        Code by <a href="">Duy Khanh</a>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->