<?php


require_once 'autoload.php';

$obj = new Json(DATA_PRODUCT, COLUMNS_PRODUCT);