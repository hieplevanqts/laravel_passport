<!-- jQuery -->
<script src="assets/js/jquery.min.js"></script>
<!-- light slider -->
<script src="assets/js/lightslider.js"></script>
<!-- Bootstrap -->
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!-- FastClick -->
<script src="assets/js/fastclick.js"></script>
<!-- NProgress -->
<script src="assets/js/nprogress.js"></script>
<!-- Chart.js -->
<script src="assets/js/Chart.min.js"></script>
<!-- gauge.js -->
<script src="assets/js/gauge.min.js"></script>
<!-- bootstrap-progressbar -->
<script src="assets/js/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="assets/js/icheck.min.js"></script>
<!-- Skycons -->
<script src="assets/js/skycons.js"></script>
<!-- Flot -->
<script src="assets/js/jquery.flot.js"></script>
<script src="assets/js/jquery.flot.pie.js"></script>
<script src="assets/js/jquery.flot.time.js"></script>
<script src="assets/js/jquery.flot.stack.js"></script>
<script src="assets/js/jquery.flot.resize.js"></script>
<script src="assets/js/date.js"></script>
<script src="assets/js/moment.min.js"></script>
<script src="assets/js/daterangepicker.js"></script>
<!-- Custom Theme Scripts -->
<script src="assets/js/custom.min.js"></script>
<script src="assets/js/myScript.js"></script>