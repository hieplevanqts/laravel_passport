<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link rel=icon href=assets/images/icon_zendvn.png sizes="16x16" type="image/png">
<!-- Meta, title, CSS, favicons, etc. -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ZendVN-Dropzone</title>
<!-- Bootstrap -->
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<!-- Font Awesome -->
<link href="assets/fonts/css/font-awesome.min.css" rel="stylesheet">
<!-- NProgress -->
<link href="assets/css/nprogress.css" rel="stylesheet">
<!-- bootstrap-wysiwyg -->
<link href="assets/css/prettify.min.css" rel="stylesheet">
<!-- Custom styling plus plugins -->
<link href="assets/css/custom.min.css" rel="stylesheet">
<link href="assets/css/myStyle.css" rel="stylesheet">
<link href="assets/css/lightslider.css" rel="stylesheet">